
# Squarespace Integration Notes

- Use a blank template and set each page to “Page → Page Header Code Injection” only if needed.
- If using page sections, you can embed sections via “Code” blocks and copy relevant HTML portions.
- Favicon uses `images/LucentAI Icon.png`. In Squarespace, also upload it under Design → Browser Icon.
